# coding=utf-8
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import requests


# Sending http requests function
def sent_http_request(target, method, headers=None, payload=None):
    headers_dict = dict()
    result = []
    if headers:
        for header in headers._headers:
            header_name = header[0]
            header_value = header[1]
            headers_dict[header_name] = header_value
    if method == "GET":
        response = requests.get(target, headers=headers_dict)
        result.append(f"[#] GET Message target: {target}\n")
    elif method == "POST":
        response = requests.post(target, headers=headers_dict, data=payload)
        result.append(f"[#] POST Message target: {target}\n"
              f"[#] Headers: {headers_dict}\n"
              f"[#] payload: {payload}\n")
    result.append(
        f"[#] Response status code: {response.status_code}\n"
        f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
        f"[#] Response content:\n {response.text}"
    )
    return result


# Ping sweeping function
def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -c 1 {scanned_ip}')
    res = response.readlines()
    result = ""
    if len(res) == 0:
        result += f"no result for {scanned_ip}"
    else:
        result += f"[#] Result of scanning: {scanned_ip} [#]\n{res[1]}"
    return result


# Request processing
class ServiceHandler(BaseHTTPRequestHandler):
    # Set header parameters for the answer
    def set_headers(self):
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        length = int(self.headers["Content-Length"])
        content = self.rfile.read(length)
        temp = str(content).strip('b\'')
        self.end_headers()
        return temp

    # Processing GET requests
    def do_GET(self):
        temp = self.set_headers()
        res = []
        temp = temp.split("\\n")
        if temp[0] == 'ping_sweep':
            for num in range(int(temp[2])):
                res.append(do_ping_sweep(temp[1], num))
            for r in res:
                self.wfile.write(r.encode())
        else:
            res = sent_http_request(temp, "GET")
            self.wfile.write(res[0].encode())
            self.wfile.write(res[1].encode())

    # Processing POST requests
    def do_POST(self):
        temp = self.set_headers()
        headers = self.headers
        res = sent_http_request(temp, "POST", headers)
        self.wfile.write(res[0].encode())
        self.wfile.write(res[1].encode())


# HTTP server launch
server = HTTPServer(('0.0.0.0', 8081), ServiceHandler)
server.serve_forever()
